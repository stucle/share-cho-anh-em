#pragma once
#include <iostream>
using namespace std;

namespace tinhtoan {
     double TinhGiaBan(float memory, float dongia);
}
namespace pack {
     string integ_toString(long num, int size = 5);
     string realnum_toString(double real, int size);
}

