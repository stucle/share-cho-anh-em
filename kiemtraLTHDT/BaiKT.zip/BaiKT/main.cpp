#include "DS_phone.h"


int main()
{
     DS_Phone danhsach;
     cout << "Nhap tu 2 den 30 smartphone: ";
     danhsach.Nhap_DS();
     danhsach.SapXep_DS();
     danhsach.Xoa_("Nokia");
     cout << "Danh sach dien thoai dc sap xep theo gia ban (khong co Nokia): ";
     danhsach.In_DS();
     system("pause");
}