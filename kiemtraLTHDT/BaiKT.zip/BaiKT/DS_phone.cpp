#include "DS_phone.h"
#include <string>

void DS_Phone::Nhap_DS(int a, int b)
{
     cout << "Nhap so luong smartphone: ";
     do cin >> this->soluong;
     while (!(a <= this->soluong <= 30));
     this->list.resize(0);
     int n = 1;
     string maso, nhanhieu;
     float dongia; int namsanxuat;
     float manhinh, camera; int bonho;
     while (n <= this->soluong)
     {
	   cout << "Smartphone  <" << n++ << "> : ";
	   cout << "Ma so dien thoai: ";
	   cin.ignore();
	   getline(cin, maso);
	   cout << "Nhan hieu: ";
	   cin.ignore();
	   getline(cin, nhanhieu);
	   cout << "Don gia: ";
	   cin >> dongia;
	   cout << "San xuat nam: ";
	   cin >> namsanxuat;
	   cout << "Kich thuoc man hinh: ";
	   cin >> manhinh;
	   cout << "Do phan giai camera: ";
	   cin >> camera;
	   cout << "Dung luong bo nho: ";
	   cin >> bonho;
	   list.push_back(SmartPhone(maso, nhanhieu, dongia, namsanxuat, manhinh, camera, bonho));
     }
}

void DS_Phone::Swap(SmartPhone &a, SmartPhone &b)
{
     SmartPhone t = a;
     a = b;
     b = t;
}

void DS_Phone::SapXep_DS()
{
     int n = list.size();
     for (int i = 0; i < n; i++)
	   for (int j = 0; j < n; j++)
		 if (list[1 + j] < list[j])
		      DS_Phone::Swap(list[1 + j], list[j]);
}

void DS_Phone::Xoa_(string key)
{
     for (int i = 0; i < list.size(); i++)
	   if (list.at(i).getNhanHieu().compare(key))
		 list.erase(list.begin() + i);
}

void DS_Phone::In_DS()
{
     int n = list.size();
     for (int i = 0; i < n; i++)
     {
	   cout << "\nSmartphone thu" << 1 + i;
	   cout << list[i].toString();
     }
}