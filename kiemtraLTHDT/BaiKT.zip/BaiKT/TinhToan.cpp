#include "package.h"

double tinhtoan::TinhGiaBan(float memory, float dongia)
{
     if (memory < 8) return dongia *= (float)(100 + 5) / 100;
     else if (8 <= memory && memory <= 16) return  dongia *= (float)(100 + 10) / 100;
     else return  dongia *= (float)(100 + 15) / 100;
}
#pragma warning(disable:4996)
string pack::integ_toString(long num, int size)
{
     char *temp = new char[size];
     itoa(num, temp, 10);
     string re(temp);
     temp = NULL, delete[] temp;
     return re;
}
string pack::realnum_toString(double real, int size)
{
     char *temp = new char[size];
     sprintf(temp, "%f", real);
     string re(temp); temp = NULL;
     return re;
}
